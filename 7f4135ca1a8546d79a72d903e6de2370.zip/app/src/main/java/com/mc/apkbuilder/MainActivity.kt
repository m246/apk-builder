package com.mc.apkbuilder

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<TextView>(R.id.textHint).text =
            "APK 打包器：把安卓项目 zip 上传到 GitHub，云端自动编译成 APK。\n\n" +
            "第 1 步：上传你的安卓项目 zip\n" +
            "第 2 步：GitHub 自动开始编译（约 5~10 分钟）\n" +
            "第 3 步：在编译结果页下载 APK 成品"

        findViewById<Button>(R.id.btnUpload).setOnClickListener {
            openUrl("https://github.com/m246/apk-builder")
        }
        findViewById<Button>(R.id.btnProgress).setOnClickListener {
            openUrl("https://github.com/m246/apk-builder/actions")
        }
        findViewById<Button>(R.id.btnDownload).setOnClickListener {
            openUrl("https://github.com/m246/apk-builder/actions")
        }
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            // 没有可用浏览器时给出提示
        }
    }
}
