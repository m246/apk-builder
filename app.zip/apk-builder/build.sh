#!/bin/sh
# 一键构建镜像（老奶奶都会：双击运行或复制这一句）
set -e
cd "$(dirname "$0")"

echo "=============================================="
echo "  开始构建 APK 打包器镜像（首次约 10~20 分钟）"
echo "=============================================="

if command -v docker >/dev/null 2>&1; then
    docker build -t apk-builder:latest .
else
    echo "!! 没找到 docker 命令"
    echo "!! 如果是云服务器：先安装 Docker（腾讯云/阿里云控制台有“一键安装 Docker”按钮）"
    exit 1
fi

echo ""
echo "✅ 构建完成！接下来运行： sh run.sh"
