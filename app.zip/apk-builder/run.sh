#!/bin/sh
# 一键启动容器（老奶奶都会）
set -e
cd "$(dirname "$0")"

echo "启动 APK 打包器…"
docker rm -f apk-builder >/dev/null 2>&1 || true
docker run -d \
  --name apk-builder \
  -p 8080:8080 \
  -e MAX_UPLOAD_MB=500 \
  -e BUILD_TIMEOUT_SECONDS=1800 \
  -v "$(pwd)/jobs:/srv/apk-builder/jobs" \
  -v "$(pwd)/uploads:/srv/apk-builder/uploads" \
  --restart unless-stopped \
  apk-builder:latest

echo ""
echo "✅ 启动完成！"
echo "   在手机/电脑浏览器打开："
echo "   http://服务器公网IP:8080"
echo ""
echo "   如果打不开："
echo "   1. 云服务器控制台 → 安全组 → 放行 TCP 8080 端口"
echo "   2. 运行 docker logs apk-builder 查看日志"
