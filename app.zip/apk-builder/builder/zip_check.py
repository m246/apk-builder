# -*- coding: utf-8 -*-
"""ZIP 文件校验：合法性、完整性、路径安全。"""
import os
import zipfile


class ZipCheckError(Exception):
    pass


def check_zip(path, max_size_mb=500):
    """校验 ZIP 是否合法、完整、安全。通过返回文件名列表，失败抛 ZipCheckError。"""
    if not os.path.exists(path):
        raise ZipCheckError("文件不存在")
    if os.path.getsize(path) == 0:
        raise ZipCheckError("文件为空")
    if os.path.getsize(path) > max_size_mb * 1024 * 1024:
        raise ZipCheckError("文件超过 %d MB 限制" % max_size_mb)

    # 魔数检查：PK\x03\x04（正常 zip）或 PK\x05\x06（空 zip）
    with open(path, "rb") as f:
        head = f.read(4)
    if head not in (b"PK\x03\x04", b"PK\x05\x06"):
        raise ZipCheckError("文件头不是 ZIP 格式（PK..），可能不是压缩包或文件损坏")

    # 完整性与结构检查
    if not zipfile.is_zipfile(path):
        raise ZipCheckError("zipfile 解析失败，压缩包可能损坏")

    names = []
    try:
        with zipfile.ZipFile(path) as zf:
            bad = zf.testzip()
            if bad is not None:
                raise ZipCheckError("压缩包内有损坏文件：%s" % bad)
            for info in zf.infolist():
                names.append(info.filename)
                # 路径穿越防护
                normalized = info.filename.replace("\\", "/")
                if normalized.startswith("/") or ".." in normalized.split("/"):
                    raise ZipCheckError("压缩包内存在不安全路径：%s" % info.filename)
    except zipfile.BadZipFile as e:
        raise ZipCheckError("压缩包损坏：%s" % e)

    if not names:
        raise ZipCheckError("压缩包是空的")
    return names
