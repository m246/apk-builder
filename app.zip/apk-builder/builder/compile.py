# -*- coding: utf-8 -*-
"""Gradle 编译调度：解压项目 → 执行 gradle assembleDebug → 产出 APK。"""
import os
import re
import shutil
import subprocess
import time
import zipfile

BUILD_TIMEOUT_SECONDS = int(os.environ.get("BUILD_TIMEOUT_SECONDS", "1800"))


def unzip_safe(zip_path, dest_dir):
    """安全解压（已通过 zip_check 校验，这里再兜底）。"""
    os.makedirs(dest_dir, exist_ok=True)
    with zipfile.ZipFile(zip_path) as zf:
        for info in zf.infolist():
            normalized = info.filename.replace("\\", "/")
            if normalized.startswith("/") or ".." in normalized.split("/"):
                raise ValueError("不安全路径: %s" % info.filename)
            target = os.path.join(dest_dir, normalized)
            if not os.path.realpath(target).startswith(os.path.realpath(dest_dir)):
                raise ValueError("路径越界: %s" % info.filename)
        zf.extractall(dest_dir)


def find_gradle_wrapper(project_dir):
    """优先用项目自带 gradlew，找不到才用系统 gradle。"""
    wrapper = os.path.join(project_dir, "gradlew")
    if os.path.exists(wrapper):
        os.chmod(wrapper, 0o755)
        return [wrapper]
    return None


def find_output_apk(project_dir):
    """在常见输出目录里找编译出的 APK。"""
    candidates = []
    for root, dirs, files in os.walk(project_dir):
        if "build" not in root or "outputs" not in root:
            continue
        if root.endswith("apk") or root.endswith("apk/debug"):
            for f in files:
                if f.endswith(".apk"):
                    candidates.append(os.path.join(root, f))
    # 优先 debug 包，其次任意 apk
    candidates.sort(key=lambda p: ("debug" not in os.path.basename(p), len(p)))
    return candidates[0] if candidates else None


def run_build(project_dir, log_sink, state):
    """
    执行编译。
    log_sink(text): 追加日志
    state: {'phase': ...} 可更新
    返回 (ok, apk_path 或 error)
    """
    cmd = find_gradle_wrapper(project_dir)
    if cmd is None:
        cmd = ["gradle"]
    cmd = cmd + ["assembleDebug", "--no-daemon", "--console=plain"]

    env = os.environ.copy()
    if "ANDROID_HOME" in env:
        env["ANDROID_SDK_ROOT"] = env.get("ANDROID_HOME")

    log_sink(">>> 执行命令: %s\n" % " ".join(cmd))
    try:
        proc = subprocess.Popen(
            cmd, cwd=project_dir, env=env,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, encoding="utf-8", errors="replace",
        )
    except FileNotFoundError:
        return False, "找不到 gradle 命令，请确认容器内已安装 Gradle 或项目自带 gradlew"

    start = time.time()
    tail = []
    while True:
        line = proc.stdout.readline()
        if line:
            tail.append(line)
            if len(tail) > 400:
                tail = tail[-400:]
            log_sink(line)
        elif proc.poll() is not None:
            break
        else:
            if time.time() - start > BUILD_TIMEOUT_SECONDS:
                proc.kill()
                return False, "编译超时（%d 秒），请检查项目或增加 BUILD_TIMEOUT_SECONDS" % BUILD_TIMEOUT_SECONDS
            time.sleep(0.2)

    if proc.returncode != 0:
        # 截取关键错误
        err_lines = [l for l in tail if re.search(r"(error|FAILURE|BUILD FAILED|Exception)", l, re.I)]
        brief = "".join(err_lines[-8:]) if err_lines else "".join(tail[-12:])
        return False, "Gradle 编译失败（退出码 %d）：\n%s" % (proc.returncode, brief.strip())

    apk = find_output_apk(project_dir)
    if not apk:
        return False, "Gradle 报告成功，但没有找到生成的 APK 文件"
    return True, apk
