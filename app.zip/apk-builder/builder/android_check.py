# -*- coding: utf-8 -*-
"""Android Studio 项目结构校验：检查关键文件是否齐全。"""


REQUIRED_CHECKS = [
    # (说明, 判定函数)
    ("settings.gradle / settings.gradle.kts",
     lambda n: "settings.gradle" in n or "settings.gradle.kts" in n),
    ("根目录 build.gradle / build.gradle.kts",
     lambda n: n == "build.gradle" or n == "build.gradle.kts"),
    ("app/build.gradle / app/build.gradle.kts",
     lambda n: n == "app/build.gradle" or n == "app/build.gradle.kts"),
    ("app/src/main/AndroidManifest.xml",
     lambda n: n == "app/src/main/AndroidManifest.xml"),
]

# 提示：可能是其他工程结构
ALT_HINTS = [
    ("项目文件可能放错层级（app 模块不在根目录）",
     lambda n: "build.gradle" in n and not n.startswith("app/") and not n == "build.gradle"),
]


def check_android_project(names):
    """names: zip 内文件路径列表。返回 (通过?, 缺失列表, 提示列表)。"""
    missing = []
    for desc, fn in REQUIRED_CHECKS:
        if not any(fn(n) for n in names):
            missing.append(desc)

    hints = []
    has_manifest = any("AndroidManifest.xml" in n for n in names)
    for desc, fn in ALT_HINTS:
        if any(fn(n) for n in names):
            hints.append(desc)
    # 有 src/main/java 代码但整个压缩包没有 AndroidManifest → 基本可断定不是安卓工程
    if any("src/main/java" in n for n in names) and not has_manifest:
        if "可能是纯 Java/Kotlin 工程，不是 Android 工程" not in hints:
            hints.append("可能是纯 Java/Kotlin 工程，不是 Android 工程")

    return (len(missing) == 0, missing, hints)
