# 🧱 APK 打包器

上传 Android Studio 项目 ZIP → 服务器自动校验 → Gradle 编译 → 下载 APK。

## 目录结构
```
apk-builder/
├── web/index.html      # 网页界面（选zip、校验、上传、看进度、下载）
├── app.py              # 后端主程序（Flask）
├── builder/
│   ├── zip_check.py    # ZIP 合法性/完整性/路径安全检查
│   ├── android_check.py# Android Studio 项目结构检查
│   └── compile.py      # Gradle 编译与 APK 查找
├── Dockerfile          # 容器镜像（JDK17 + Android SDK + Gradle + Flask）
├── docker-compose.yml
├── build.sh            # 一键构建镜像
└── run.sh              # 一键启动容器
```

## 工作流程（4 步，和网页上的编号一致）
1. **选 zip**：网页选 Android Studio 项目压缩包
2. **本地检查**：浏览器 JS 检查 ZIP 魔数 + 扫描内部文件，缺 `settings.gradle` / `build.gradle` / `app/build.gradle` / `AndroidManifest.xml` 会直接提示
3. **服务器校验**：后端再校验 ZIP 完整性、路径安全（防 `../` 穿越）、项目结构
4. **编译**：解压 → `gradle assembleDebug` → 弹窗给 APK 下载链接

## 部署（云服务器上操作，照着抄即可）

### 第一次部署（只做一次）
```bash
# 1. 把 apk-builder 文件夹整个上传到服务器任意位置
# 2. 进到文件夹
cd apk-builder
# 3. 一键构建镜像（约 10~20 分钟，取决于网速）
sh build.sh
```

### 每次启动
```bash
cd apk-builder
sh run.sh
```

### 打开使用
手机/电脑浏览器访问：
```
http://服务器公网IP:8080
```
打不开时：云服务器控制台 → 安全组 → 放行 **TCP 8080** 端口。

### 不用 Docker 直接跑（调试用）
```bash
pip3 install -r requirements.txt
python3 app.py
```
然后浏览器打开 `http://127.0.0.1:8080`。

## 环境变量（可改可不改）
| 变量 | 默认 | 说明 |
|---|---|---|
| `PORT` | 8080 | 服务端口 |
| `MAX_UPLOAD_MB` | 500 | 上传 zip 大小上限 |
| `BUILD_TIMEOUT_SECONDS` | 1800 | 编译超时（秒） |

## 已验证 ✅
- ZIP 魔数/完整性/路径穿越拦截
- Android 项目结构缺失检测
- 上传 → 校验 → 解压 → 编译 → done → 下载 全链路（模拟编译环境测试通过）
- 伪 zip 上传时直接拒收

## 注意事项
- 首次编译真实项目时，Gradle 会下载依赖，可能需要几分钟到十几分钟，属正常现象
- 上传的项目 Gradle 版本、SDK 版本需与镜像内版本兼容（JDK17 / Gradle 8.7 / compileSdk 34~35）；不兼容会编译报错，日志会给出原因
- 容器内预装了 `platforms;android-34/35` 与 `build-tools;34.0.0/35.0.0`，如需更高版本改 Dockerfile 重新构建
