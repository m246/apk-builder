# -*- coding: utf-8 -*-
"""APK 打包器 - Flask 后端主程序

功能：
  1. 接收上传的 ZIP（Android Studio 项目）
  2. 校验：合法 ZIP + 完整 Android 项目结构
  3. 后台串行执行 Gradle 编译
  4. 编译完成提供 APK 下载
"""
import os
import shutil
import threading
import time
import uuid

from flask import Flask, jsonify, request, send_from_directory

from builder.zip_check import check_zip, ZipCheckError
from builder.android_check import check_android_project
from builder import compile as compile_mod

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
JOBS_DIR = os.path.join(BASE_DIR, "jobs")
WEB_DIR = os.path.join(BASE_DIR, "web")
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(JOBS_DIR, exist_ok=True)

MAX_UPLOAD_MB = int(os.environ.get("MAX_UPLOAD_MB", "500"))

app = Flask(__name__, static_folder=None)
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_MB * 1024 * 1024

# 任务表：job_id -> {state, error, apk_name, apk_path, apk_url, log_tail, created}
JOBS = {}
JOBS_LOCK = threading.Lock()
QUEUE = []          # job_id 列表，串行消费
QUEUE_COND = threading.Condition()
WORKER_STARTED = False


def new_job():
    job_id = uuid.uuid4().hex[:12]
    JOBS[job_id] = {
        "state": "queued",
        "error": None,
        "apk_name": None,
        "apk_path": None,
        "apk_url": None,
        "log_tail": "",
        "created": time.time(),
    }
    return job_id


def set_job(job_id, **kw):
    with JOBS_LOCK:
        JOBS[job_id].update(kw)


def append_log(job_id, text):
    with JOBS_LOCK:
        tail = JOBS[job_id]["log_tail"] + text
        if len(tail) > 12000:
            tail = tail[-12000:]
        JOBS[job_id]["log_tail"] = tail


def worker_loop():
    """串行消费编译队列，一次只编译一个任务。"""
    while True:
        with QUEUE_COND:
            while not QUEUE:
                QUEUE_COND.wait()
            job_id = QUEUE.pop(0)
        try:
            process_job(job_id)
        except Exception as e:  # 兜底，不拖垮 worker
            set_job(job_id, state="failed", error="内部错误：%s" % e)
            append_log(job_id, "!!! 内部错误: %s\n" % e)


def process_job(job_id):
    job_dir = os.path.join(JOBS_DIR, job_id)
    os.makedirs(job_dir, exist_ok=True)
    zip_path = os.path.join(job_dir, "source.zip")

    # ---------- 第 1 步：ZIP 合法性 ----------
    set_job(job_id, state="checking")
    append_log(job_id, "[1/4] 正在校验 ZIP 文件…\n")
    try:
        names = check_zip(zip_path, MAX_UPLOAD_MB)
    except ZipCheckError as e:
        set_job(job_id, state="failed", error="ZIP 校验失败：%s" % e)
        append_log(job_id, "!!! %s\n" % e)
        return
    append_log(job_id, "    ZIP 合法，共 %d 个文件\n" % len(names))

    # ---------- 第 2 步：Android 项目结构 ----------
    append_log(job_id, "[2/4] 正在检查 Android Studio 项目结构…\n")
    ok, missing, hints = check_android_project(names)
    for m in missing:
        append_log(job_id, "    缺失: %s\n" % m)
    if not ok:
        set_job(job_id, state="failed",
                error="不是完整的 Android Studio 项目，缺少：%s" % "、".join(missing))
        return
    for h in hints:
        append_log(job_id, "    提示: %s\n" % h)
    append_log(job_id, "    项目结构完整 ✓\n")

    # ---------- 第 3 步：解压 + 编译 ----------
    set_job(job_id, state="building")
    project_dir = os.path.join(job_dir, "project")
    append_log(job_id, "[3/4] 正在解压项目…\n")
    try:
        compile_mod.unzip_safe(zip_path, project_dir)
    except Exception as e:
        set_job(job_id, state="failed", error="解压失败：%s" % e)
        return
    append_log(job_id, "    解压完成，开始编译（首次编译较慢，请耐心等待）\n")

    append_log(job_id, "[4/4] 正在执行 Gradle 编译…\n")
    state = {}
    ok, result = compile_mod.run_build(project_dir, lambda t: append_log(job_id, t), state)
    if not ok:
        set_job(job_id, state="failed", error=result)
        append_log(job_id, "!!! 编译失败\n")
        return

    # ---------- 产物处理 ----------
    apk_path = result
    apk_name = os.path.basename(apk_path)
    final_name = "app-debug.apk" if not apk_name.startswith("app-") else apk_name
    final_path = os.path.join(job_dir, final_name)
    shutil.copy2(apk_path, final_path)
    append_log(job_id, "    APK 生成完毕: %s\n" % final_name)

    set_job(job_id, state="done",
            apk_name=final_name,
            apk_path=final_path,
            apk_url="/download/%s/%s" % (job_id, final_name))


# ---------------- HTTP 接口 ----------------

@app.route("/")
def index():
    return send_from_directory(WEB_DIR, "index.html")


@app.errorhandler(413)
def too_large(e):
    return jsonify(ok=False, error="文件超过 %d MB 限制" % MAX_UPLOAD_MB), 413


@app.route("/api/upload", methods=["POST"])
def upload():
    global WORKER_STARTED
    f = request.files.get("file")
    if f is None:
        return jsonify(ok=False, error="没有收到文件字段 file"), 400
    if not f.filename.lower().endswith(".zip"):
        return jsonify(ok=False, error="请上传 .zip 文件"), 400

    # 快速魔数检查：不是 zip 头直接拒收，避免浪费队列资源
    head = f.stream.read(4)
    f.stream.seek(0)
    if head not in (b"PK\x03\x04", b"PK\x05\x06"):
        return jsonify(ok=False, error="文件头不是 ZIP 格式，文件可能损坏或不是压缩包"), 400

    job_id = new_job()
    job_dir = os.path.join(JOBS_DIR, job_id)
    os.makedirs(job_dir, exist_ok=True)
    f.save(os.path.join(job_dir, "source.zip"))

    with QUEUE_COND:
        QUEUE.append(job_id)
        QUEUE_COND.notify()
    if not WORKER_STARTED:
        t = threading.Thread(target=worker_loop, daemon=True)
        t.start()
        WORKER_STARTED = True

    return jsonify(ok=True, job_id=job_id)


@app.route("/api/status/<job_id>")
def status(job_id):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
        if job is None:
            return jsonify(ok=False, error="任务不存在"), 404
        info = dict(job)
    return jsonify(ok=True, **info)


@app.route("/download/<job_id>/<filename>")
def download(job_id, filename):
    job_dir = os.path.join(JOBS_DIR, job_id)
    if not os.path.isdir(job_dir):
        return "任务不存在", 404
    # 只允许下载任务目录内的文件
    real = os.path.realpath(os.path.join(job_dir, filename))
    if not real.startswith(os.path.realpath(job_dir)) or not filename.endswith(".apk"):
        return "非法请求", 400
    if not os.path.exists(real):
        return "文件不存在", 404
    return send_from_directory(job_dir, filename, as_attachment=True)


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8080"))
    app.run(host="0.0.0.0", port=port, threaded=True)
